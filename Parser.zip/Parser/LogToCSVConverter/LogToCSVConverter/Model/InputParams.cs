﻿namespace LogToCSVConverter.Model
{
    public class InputParams
    {
        public string Command { get; set; }
        public string Data { get; set; }
    }
}
